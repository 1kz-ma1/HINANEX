# HINANEX Pipeline

10/22 洪水MVP向けのデータ収集・正規化・評価基盤。

## 現在地

実装済み:

- Python 3.12 前提の最小環境
- `Evidence`, `DataRequirement`, `NormalizedDataset`, `PipelineResult`
- 避難所共通Schema `ShelterRecord`
- 評価モデルの型 (`DiscoveryStatus`, Data Quality, Application Readiness)
- SourceAdapterの共通インターフェース
- PydanticモデルのJSON出力
- 江戸川区モック避難所3件による配管テスト
- 最小モデルテスト

未実装:

- 実データ取得Adapter
- Rawデータの実保存処理
- Data Quality / Application Readiness の実判定ロジック
- Capability / Gap判定ロジック
- 実データを使った江戸川区評価

## セットアップ

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## 動作確認

```powershell
python main.py
python -m unittest discover -s tests -v
```

`python main.py` が成功すると以下を生成する。

```text
data/normalized/mock_edogawa_shelters.json
```

## 次の実装

A担当が調査した江戸川区の実データソースを使い、最初の実 `SourceAdapter` を作る。

最初の縦スライス:

```text
公式データ取得
-> data/rawへ保存
-> ShelterRecordへ正規化
-> NormalizedDataset
-> JSON出力
```

実データの形式が確定するまでは自治体固有処理を共通Schemaへ持ち込まない。
