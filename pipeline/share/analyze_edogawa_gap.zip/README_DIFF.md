# HINANEX D担当 v0.8 — 3地域統合出力 / B・C引き渡し契約

## 今回の目的

江戸川区・新潟市・名古屋市で個別に生成していた成果物を、B担当とC担当が直接利用できる**1地域1JSON**へ統合します。

v0.8では新しい防災評価ロジックは増やしません。D担当が作った基盤を「他担当が使える契約」として固定する仕上げ工程です。

## 差分

- `src/hinanex/models/export.py`
  - `RegionInfo`
  - `ExportMeta`
  - `RegionExport`
- `src/hinanex/export.py`
  - Dataset / Assessment / Capability / GapAnalysisを1地域の共通契約へ統合
  - Gap / RecommendationをUI向けにフラット化
  - 地域混在を拒否
  - 既存JSON成果物からの再構築
- `build_region_contracts.py`
  - 3地域の既存成果物から `data/output/*.json` を一括生成
- `docs/HANDOFF_CONTRACT_v0.8.md`
  - B担当UI用フィールド
  - C担当検証トレース
  - `0 != null`、Gap種別などの解釈を固定
- `tests/test_export.py`
  - Schema固定
  - 件数/meta
  - Gap/Recommendation展開
  - 地域混在拒否
  - 既存JSONからの再構築

## 適用後の実行

3地域のworkflowがすでに成功済みなら、まず統合だけでOKです。

```powershell
cd C:\hinanex-pipeline
.\.venv\Scripts\Activate.ps1

python build_region_contracts.py
python -m unittest discover -s tests -v
```

既存JSONを作り直したい場合は先に以下を実行してください。

```powershell
python run_edogawa.py
python assess_edogawa.py
python assess_edogawa_capability.py
python analyze_edogawa_gap.py
python run_niigata_workflow.py
python run_nagoya_workflow.py
python build_region_contracts.py
```

## 生成物

```text
data/output/
├─ edogawa.json
├─ niigata.json
└─ nagoya.json
```

各JSONのトップレベルは共通です。

```text
region
datasets
assessments
capabilities
gaps
recommendations
meta
```

## D担当MVPの完了判定

v0.8が3地域で生成でき、全テストが通れば、D担当の中間MVPの**基盤実装は完了**として扱えます。

以後のD作業は、B/Cとの結合で判明した不整合修正、Aから追加データが来た場合のAdapter/DataRequirement追加、評価ルールの検証結果反映が中心です。
