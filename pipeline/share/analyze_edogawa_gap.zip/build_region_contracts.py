from dataclasses import dataclass
from pathlib import Path

from src.hinanex.export import write_region_export_from_paths


@dataclass(frozen=True)
class RegionArtifacts:
    key: str
    dataset: str
    assessment: str
    capability: str
    gap: str


REGIONS = [
    RegionArtifacts(
        key="edogawa",
        dataset="data/normalized/edogawa_shelters.json",
        assessment="data/normalized/edogawa_shelter_location_assessment.json",
        capability="data/normalized/edogawa_shelter_discovery_capability.json",
        gap="data/normalized/edogawa_shelter_discovery_gap.json",
    ),
    RegionArtifacts(
        key="niigata",
        dataset="data/normalized/niigata_shelters.json",
        assessment="data/normalized/niigata_shelter_location_assessment.json",
        capability="data/normalized/niigata_shelter_discovery_capability.json",
        gap="data/normalized/niigata_shelter_discovery_gap.json",
    ),
    RegionArtifacts(
        key="nagoya",
        dataset="data/normalized/nagoya_shelters.json",
        assessment="data/normalized/nagoya_shelter_location_assessment.json",
        capability="data/normalized/nagoya_shelter_discovery_capability.json",
        gap="data/normalized/nagoya_shelter_discovery_gap.json",
    ),
]


def _assert_inputs_exist(region: RegionArtifacts) -> None:
    required = [
        region.dataset,
        region.assessment,
        region.capability,
        region.gap,
    ]
    missing = [path for path in required if not Path(path).exists()]

    if missing:
        joined = "\n  - ".join(missing)
        raise FileNotFoundError(
            f"{region.key} の統合前成果物が不足しています:\n  - {joined}\n"
            "先に各地域workflowを実行してください。"
        )


def main() -> None:
    print("=== HINANEX B/C contract build ===")

    for region in REGIONS:
        _assert_inputs_exist(region)

        output_path = write_region_export_from_paths(
            output_path=f"data/output/{region.key}.json",
            dataset_paths=[region.dataset],
            assessment_paths=[region.assessment],
            capability_paths=[region.capability],
            gap_paths=[region.gap],
        )

        print(f"{region.key}: {output_path}")

    print("Done: 3 region contracts generated.")


if __name__ == "__main__":
    main()
